const name=('Umar')
console.log( name );

const age=('18')
console.log( age );

const fathername=('M.Saleem')
console.log(fathername);

