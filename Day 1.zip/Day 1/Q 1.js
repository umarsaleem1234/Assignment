let x=('hello');
console.log(x);

var y=('Kya hal ha!')
console.log(y)

const z=('Theek hu')
console.log(z)