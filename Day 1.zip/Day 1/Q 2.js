const y=('100');

y=50;

console.log(y);
//Type Error

